resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'ESX Gate system'

version '1.0.0'

client_scripts {
    '@es_extended/locale.lua',
    'client.lua',
	'config.lua',
	'prop.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    '@es_extended/locale.lua',
    'server.lua'
}
