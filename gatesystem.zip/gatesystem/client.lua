ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(0)
    end
end)

local openGateCoords = vector3(-714.0580, -1422.1138, 5.2647)  
local closeGateCoords = vector3(-718.1100, -1422.1274, 5.3005) 

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        -- Open gate
        if GetDistanceBetweenCoords(playerCoords, openGateCoords, true) < 1.5 then
            DrawText3D(openGateCoords.x, openGateCoords.y, openGateCoords.z, "[E] Open the gate")

            if IsControlJustReleased(0, 38) then -- 'E' 
                TriggerServerEvent('open:setDoorState') 
            end
        end

        -- Close gate
        if GetDistanceBetweenCoords(playerCoords, closeGateCoords, true) < 1.5 then
            DrawText3D(closeGateCoords.x, closeGateCoords.y, closeGateCoords.z, "[E] Close the gate")

            if IsControlJustReleased(0, 38) then -- 'E'
				TriggerServerEvent('close:setDoorState')
            end
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 150)
end