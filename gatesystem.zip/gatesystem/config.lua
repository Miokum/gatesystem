Config = {}

Config.Prop = { 
   [1] = {
        prop = `prop_elecbox_23`,
        propcoords = vector4(-718.1100, -1422.1274, 5.3005, 143.7240),
    }
}



