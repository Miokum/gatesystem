CreateThread(function()
    for i = 1, #Config.Prop do
        if Config.Prop[i].propcoords ~= nil then
            local heading = Config.Prop[i].propcoords[4]-180
            RequestModel(Config.Prop[i].prop)
            while not HasModelLoaded(Config.Prop[i].prop) do
                Wait(1) 
            end
            Config.Prop[i].prop = CreateObject(Config.Prop[i].prop, Config.Prop[i].propcoords.x, Config.Prop[i].propcoords.y, Config.Prop[i].propcoords.z-1, false, true, true)
            SetEntityHeading(Config.Prop[i].prop, heading)
            FreezeEntityPosition(Config.Prop[i].prop, 1)
        end	
    end
end)

 AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        for i = 1, #Config.Prop do
            if Config.Prop[i].propcoords ~= nil then
                 DeleteEntity(Config.Prop[i].prop)
            end	
        end
    end
end)
	
