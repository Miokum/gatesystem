ESX = nil

ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent('open:setDoorState')
AddEventHandler('open:setDoorState', function(doorId, state)
	exports.ox_doorlock:setDoorState(2, 0)
end)

RegisterNetEvent('close:setDoorState')
AddEventHandler('close:setDoorState', function(doorId, state)
	exports.ox_doorlock:setDoorState(2, 1)
end)
